
import './App.css';
import Counter from './Counter/counter';


function App() {
  return (
    <div className="App">
      <Counter></Counter>
    </div>
  );
}

export default App;
